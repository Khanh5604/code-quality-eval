# Another module with some simple code

def add(a, b):
    return a + b

def mul(a, b):
    return a * b

def badly_formatted( a,b ):
    # bad spacing on purpose
    if a> b:
        return a-b
    else:
        return b-a
