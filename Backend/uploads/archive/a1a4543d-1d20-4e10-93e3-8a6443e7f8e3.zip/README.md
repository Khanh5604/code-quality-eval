# Demo Quality Issues Project

This project is intentionally written with issues to demonstrate:
- ESLint findings (unused vars, undefined vars, accidental globals, etc.)
- JSCPD duplication (copy-paste blocks across files)
- CLOC/SLOC metrics (code/comment lines)
