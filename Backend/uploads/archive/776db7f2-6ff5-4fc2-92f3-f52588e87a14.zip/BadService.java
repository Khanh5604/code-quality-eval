
public class BadService {

    public void process() {
        int unused = 0;
        try {
            int x = 10 / 0;
        } catch (Exception e) {
        }
    }
}
