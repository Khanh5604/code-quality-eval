
function calculateInvoiceTotal(items) {
  let total = 0;
  let tax = 0;
  let discount = 0;

  for (let i = 0; i < items.length; i++) {
    total += items[i].price * items[i].quantity;
    tax += items[i].price * 0.1;

    if (items[i].quantity > 10) {
      discount += items[i].price * 0.05;
    }
  }

  total = total + tax - discount;
  return total;
}
