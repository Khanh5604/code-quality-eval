import { sum, multiply } from "./util.js";

function main() {
  const a = 3;
  const b = 4;
  console.log("Sum:", sum(a, b));
  console.log("Multiply:", multiply(a, b));
}

main();
