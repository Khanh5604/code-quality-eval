// Extra logic added in v2
export function power(a, b) {
  return Math.pow(a, b);
}
