
// no lint, no comments, magic numbers everywhere
for(let i=0;i<100;i++){
  for(let j=0;j<100;j++){
    for(let k=0;k<100;k++){
      console.log(i*j*k*999);
    }
  }
}
