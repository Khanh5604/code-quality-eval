
// Bad version with poor style and high complexity

function calc(a,b,c,d,e,f){
if(a>0){
if(b>0){
if(c>0){
if(d>0){
if(e>0){
if(f>0){
return a+b+c+d+e+f;
}}}}}}
return 0;
}

console.log(calc(1,2,3,4,5,6));
