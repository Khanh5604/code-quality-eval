
// duplicated and unused functions

function add(a,b){return a+b;}
function add2(a,b){return a+b;}
function add3(a,b){return a+b;}

module.exports = { add, add2, add3 };
